#pragma once

void *watch_time();
